1. Run S3DriveMountSetup.exe
2. Follow the installation wizard
3. The application will start automatically after installation and on system startup